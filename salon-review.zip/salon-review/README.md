# 💎 脱毛サロン 口コミ自動生成アプリ

**Coco starry** のお客様向け口コミ作成ツールです。  
年代・性別・職業・来店店舗を選び、AIが自然な口コミ文章を自動生成します。

---

## 📁 ファイル構成

```
salon-review/
├── public/
│   └── index.html   ← アプリ本体（これだけで動きます）
├── vercel.json      ← Vercel公開設定
├── .gitignore
└── README.md
```

---

## 🚀 GitHubにアップロードする手順

### 1. GitHubでリポジトリを作成

1. [https://github.com/new](https://github.com/new) を開く
2. Repository name に `salon-review` と入力
3. **Private**（非公開）を選択 ✅
4. 「Create repository」をクリック

### 2. このフォルダをGitHubにアップロード

ターミナル（Mac: ターミナル.app / Windows: PowerShell）で以下を実行：

```bash
# このフォルダに移動（ダウンロード先に合わせて変更）
cd ~/Downloads/salon-review

# Gitを初期化
git init

# 全ファイルをステージング
git add .

# コミット
git commit -m "初回アップロード"

# GitHubのリポジトリと接続（URLはGitHubで確認）
git remote add origin https://github.com/【あなたのID】/salon-review.git

# アップロード
git branch -M main
git push -u origin main
```

> **GitHubのURLの確認方法：**  
> リポジトリ作成後の画面に `https://github.com/xxx/salon-review.git` が表示されます。

---

## 🌐 Vercelで公開する手順

### 1. Vercelにサインアップ（無料）

1. [https://vercel.com](https://vercel.com) を開く
2. 「Sign Up」→「Continue with GitHub」でGitHubアカウントでログイン

### 2. プロジェクトをインポート

1. Vercelダッシュボードで「**Add New → Project**」をクリック
2. 「Import Git Repository」から `salon-review` を選択
3. 「**Import**」をクリック

### 3. そのままデプロイ

設定は変更不要です。「**Deploy**」をクリックするだけ！

### 4. URLをコピーしてQRコード作成

デプロイ完了後、`https://salon-review-xxxx.vercel.app` のような  
URLが発行されます。このURLでアプリが世界中から使えます。

> **QRコード作成（無料）：**  
> [https://qr.quel.jp/](https://qr.quel.jp/) にURLを貼り付けるだけでQRコードが作れます。

---

## 🔄 アプリを更新したいとき

`public/index.html` を編集後、ターミナルで：

```bash
git add .
git commit -m "更新内容を一言で"
git push
```

GitHubにプッシュすると **Vercelが自動で再デプロイ**します。

---

## ⚙️ アプリの機能

| 機能 | 内容 |
|------|------|
| 店舗選択 | 久留米店・筑紫野店・大橋店 |
| 年代選択 | 10代〜50代〜 |
| 性別選択 | 女性・男性・その他 |
| 職業選択 | 10種類 |
| キーワード選択 | 5つの質問×最大2個 |
| AI生成 | Claude APIで自然な口コミ文を自動生成 |
| LINE送信 | 生成した文をLINEでそのまま送信 |
| コピー | クリップボードにコピー |
| 管理者パネル | キーワードの追加・削除 |
